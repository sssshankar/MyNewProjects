package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {
	@GetMapping("/first")
    public String index(Model model) {
		model.addAttribute("message", "Hello, Spring Boot!"); // This will be displayed in the HTML page
        return "index"; // This corresponds to the index.html file in the templates folder
    }
}
