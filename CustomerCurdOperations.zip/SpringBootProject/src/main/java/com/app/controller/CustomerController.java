	package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Customer;
import com.app.repository.CustomerRepo;


@RestController
//@RequestMapping("/hello")
public class CustomerController {

@Autowired(required=true)
	private CustomerRepo custrepo;
	
    //save the customer
	@PostMapping("/saveCust")
	public Customer saveCustomer(@RequestBody Customer cust)
	{
		System.out.println("this is the save forms");
		return custrepo.save(cust);
	}
	
	
	//get all customers list
	@GetMapping("/getAllCust")
	private List<Customer> getAllCustomers()   
	{  
	return custrepo.findAll(); 
	}  
	
	//Getting One Customer to display
	@GetMapping("/customer/{id}")  
	private Customer getBooks(@PathVariable("id") int id)   
	{  
	return custrepo.getById(id);  
	}  
	
	//creating a delete mapping that deletes a specified Customer  
	@DeleteMapping("/cust/{id}")  
	private void deleteCustomer(@PathVariable("id") int id)   
	{  
		custrepo.deleteById(id);
	}  
	
	//creating put mapping that updates the book detail   
		@PostMapping("/updaterecord")  
		private Customer saveAll(@RequestBody Customer customer)   
		{  
			custrepo.saveAndFlush(customer);
		return customer;  
		} 
	
	
	
	
		//Save the bulk operations
		@PostMapping("/allcustomers")
	    public List<Customer> addMultipleProducts(@RequestBody List<Customer> customers) {
	        return custrepo.saveAllAndFlush(customers);
	    }
	
	
	
	
	
	

}
