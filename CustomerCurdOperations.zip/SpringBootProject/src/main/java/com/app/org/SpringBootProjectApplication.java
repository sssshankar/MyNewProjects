package com.app.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication

@EntityScan("com.app.*")
@EnableJpaRepositories("com.app.repository")

@ComponentScan(basePackages = { "com.app.model","com.app.controller","com.app.repository","com.app*"})

public class SpringBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjectApplication.class, args);
		
		System.out.println("hello this is my first Project");
		
	}
}
